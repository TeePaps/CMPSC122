// Complex.h - Complex type definition
// Written by Ted Papaioannou

// Complex.h - Complex type definition
// Written by Ted Papaioannou

#include <iostream>
#pragma once // EVERY header file created needs this!
// Use because you may use the same header twice
#include <cmath>

#define PI 3.14159265

// User defined type (aka class) Complex
struct Complex
{
	// DATA MEMBERS
	// Real party of the complex number
	float Re;
	// Imaginary part of the complex number
	float Im;

	// Init-constructor (doubles as default constructor)
	Complex(float real = 0.0f, float imaginary = 0.0f /* default argument*/)
		// default argument must be at the end of the list
	{
		Re = real;
		Im = imaginary;
	}

	// Copy-constructor
	Complex(const Complex& source)
	{
		Re = source.Re;
		Im = source.Im;
	}

	// MEMBER FUNCTIONS (MEMBER OPERATORS)
	// Binary (means takes two operands) plus operator
	// Global operator for adding two complex numbers together
	// Operator that doesn't modify any members should be type const
	Complex complement() const
	{
		return Complex(Re, -Im);
	}

	Complex operator + (const Complex& right) const
	{
		return Complex(Re + right.Re, Im + right.Im);
	}

	// Binary minus operator
	// Global operator for subtracting two complex numbers together
	Complex operator - (const Complex& b) const
	{
		return Complex(Re - b.Re, Im - b.Im);
	}

	Complex operator * (const Complex& b) const
	{
		return Complex(Re * b.Re + Im * b.Im, Re * b.Im + Im * b.Re);
	}

	Complex operator / (const Complex& b) const
	{
		Complex numerator = *this * b.complement();
		float divisor = b.Absolute() * b.Absolute();
		return Complex(numerator.Re/divisor, numerator.Im/divisor);
	}

	// Absolute value member function
	float Absolute() const /* Means that the function does NOT modify class data members */
	{
		return sqrt(Re*Re + Im*Im);
	}

	float Phasor() const
	{
		float phi = atan(Im/Re)/1.0f * 180.0f/PI;
		if (Re<0 && Im < 0)
			return (phi - 180.0f);
		else if (Re<0)
			return phi + 180.0f;
		else 
			return phi;
	}
}; // ALWAYS put a semicolon at the end of struct or class
	// If it is missing, error list will tell you you're missing one in main
	// For online help: put cursor on text and click F1

// GLOBAL stream output operator for class Complex
// have to use ostream in order to use cout
std::ostream& operator << (std::ostream& out, const Complex& myComplex)
{
	return
		out << myComplex.Re << " + i" << myComplex.Im;
}
